---
name: design-research
description: User research skills for designers: personas, empathy maps, journey maps, interview scripts, usability testing, and card sorting. Covers: affinity-diagram, card-sort-analysis, diary-study-plan, empathy-map, interview-script, jobs-to-be-done, journey-map, research-repository, summarize-interview, survey-design, usability-test-plan, user-persona.
---
# Design Research

User research skills for designers: personas, empathy maps, journey maps, interview scripts, usability testing, and card sorting.

## How to use this skill

This bundles 12 focused skills. Find the one that matches the request in the table below, then read its file before answering — the table is only an index, the actual guidance lives in the linked files.

| Skill | File | Use it for |
| --- | --- | --- |
| `affinity-diagram` | `skills/affinity-diagram/SKILL.md` | Cluster many qualitative data points into themes and insight statements. |
| `card-sort-analysis` | `skills/card-sort-analysis/SKILL.md` | Analyse open or closed card sort results into a proposed grouping and label set. |
| `diary-study-plan` | `skills/diary-study-plan/SKILL.md` | Design a diary study — prompts, cadence, duration, participant criteria, and analysis frame. |
| `empathy-map` | `skills/empathy-map/SKILL.md` | Build a Says, Thinks, Does, Feels map for one user or segment. |
| `interview-script` | `skills/interview-script/SKILL.md` | Write a structured interview guide — warm-up, core exploration, and wrap-up. |
| `jobs-to-be-done` | `skills/jobs-to-be-done/SKILL.md` | Map functional, emotional, and social jobs with outcome expectations. |
| `journey-map` | `skills/journey-map/SKILL.md` | Map one persona's end-to-end experience with stages, touchpoints, emotions, and pain points. |
| `research-repository` | `skills/research-repository/SKILL.md` | Build a repository that makes findings findable, reusable, and cumulative across teams. |
| `summarize-interview` | `skills/summarize-interview/SKILL.md` | Turn one interview transcript into themes, supporting quotes, and action items. |
| `survey-design` | `skills/survey-design/SKILL.md` | Design unbiased survey instruments — question wording, scales, and sampling — to measure attitudes at scale. |
| `usability-test-plan` | `skills/usability-test-plan/SKILL.md` | Design a usability study — research questions, methodology, participant criteria, metrics, and facilitation guide. |
| `user-persona` | `skills/user-persona/SKILL.md` | Build research-grounded personas with goals, frustrations, and behavioural patterns. |

## Multi-step workflows

These chain several of the skills above into one end-to-end process. Read the file when a request matches the whole workflow rather than a single skill.

- `commands/discover.md` — Run a full user research cycle — persona creation, empathy mapping, and journey mapping for a product or feature.
- `commands/interview.md` — Prepare an interview script or summarize an interview transcript into structured insights.
- `commands/synthesize.md` — Synthesize research data into affinity diagrams, themes, and actionable insights.
- `commands/test-plan.md` — Run the full usability study workflow — research questions, participant criteria, tasks, metrics, and facilitation guide.

## Attribution

From the Designer Skills suite by MC Dean (https://marieclairedean.substack.com/), MIT licensed.
