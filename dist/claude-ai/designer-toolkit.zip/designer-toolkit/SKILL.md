---
name: designer-toolkit
description: Essential designer utilities for writing rationale, building presentations, crafting case studies, UX writing, and driving adoption. Covers: case-study, design-negotiation, design-rationale, design-system-adoption, design-token-audit, presentation-deck, ux-writing.
---
# Designer Toolkit

Essential designer utilities for writing rationale, building presentations, crafting case studies, UX writing, and driving adoption.

## How to use this skill

This bundles 7 focused skills. Find the one that matches the request in the table below, then read its file before answering — the table is only an index, the actual guidance lives in the linked files.

| Skill | File | Use it for |
| --- | --- | --- |
| `case-study` | `skills/case-study/SKILL.md` | Craft a portfolio case study with narrative arc, process evidence, and outcomes. |
| `design-negotiation` | `skills/design-negotiation/SKILL.md` | Advocate for design quality, scope, and timeline with partners and leadership using evidence and shared goals. |
| `design-rationale` | `skills/design-rationale/SKILL.md` | Write rationale connecting decisions to user needs, business goals, and principles. |
| `design-system-adoption` | `skills/design-system-adoption/SKILL.md` | Create adoption strategy and enablement materials to drive design system usage. |
| `design-token-audit` | `skills/design-token-audit/SKILL.md` | Audit token usage across a product for coverage, drift, and hard-coded values. |
| `presentation-deck` | `skills/presentation-deck/SKILL.md` | Structure a design presentation for a specific audience and decision. |
| `ux-writing` | `skills/ux-writing/SKILL.md` | Write interface copy — microcopy, error messages, empty states, and CTAs. |

## Multi-step workflows

These chain several of the skills above into one end-to-end process. Read the file when a request matches the whole workflow rather than a single skill.

- `commands/build-presentation.md` — Build a design presentation end to end — audience framing, narrative structure, and supporting rationale.
- `commands/write-case-study.md` — Build a portfolio case study end to end — project framing, process narrative, outcomes, and visuals.
- `commands/write-rationale.md` — Write design rationale for a set of decisions, linking each to user needs, business goals, and principles.

## Attribution

From the Designer Skills suite by MC Dean (https://github.com/Owl-Listener/designer-skills), MIT licensed.
