---
name: designer-toolkit
description: Essential designer utilities for writing rationale, building presentations, crafting case studies, UX writing, and driving adoption. Covers: case-study, design-negotiation, design-rationale, design-system-adoption, design-token-audit, presentation-deck, ux-writing.
---
# Designer Toolkit

Essential designer utilities for writing rationale, building presentations, crafting case studies, UX writing, and driving adoption.

## How to use this skill

This bundles 7 focused skills as reference files. Match the request to a row below, then read that file before answering — the table is only an index, the guidance itself lives in the files.

| Skill | File | Use it for |
| --- | --- | --- |
| `case-study` | `reference/case-study.md` | Craft a portfolio case study with narrative arc, process evidence, and outcomes |
| `design-negotiation` | `reference/design-negotiation.md` | Advocate for design quality, scope, and timeline with partners and leadership using evidence and shared goals |
| `design-rationale` | `reference/design-rationale.md` | Write rationale connecting decisions to user needs, business goals, and principles |
| `design-system-adoption` | `reference/design-system-adoption.md` | Create adoption strategy and enablement materials to drive design system usage |
| `design-token-audit` | `reference/design-token-audit.md` | Audit token usage across a product for coverage, drift, and hard-coded values |
| `presentation-deck` | `reference/presentation-deck.md` | Structure a design presentation for a specific audience and decision |
| `ux-writing` | `reference/ux-writing.md` | Write interface copy — microcopy, error messages, empty states, and CTAs |

## Multi-step workflows

Each chains several skills above into one end-to-end process. Read the file when the request matches the whole workflow, not a single skill.

- `workflows/build-presentation.md` — Build a design presentation end to end — audience framing, narrative structure, and supporting rationale
- `workflows/write-case-study.md` — Build a portfolio case study end to end — project framing, process narrative, outcomes, and visuals
- `workflows/write-rationale.md` — Write design rationale for a set of decisions, linking each to user needs, business goals, and principles

## Attribution

From the Designer Skills suite by MC Dean (https://github.com/Owl-Listener/designer-skills), MIT licensed.
