---
name: design-ops
description: Streamline design operations with critique frameworks, handoff specs, sprint planning, review processes, and team workflows. Covers: design-critique, design-debt-audit, design-impact-reporting, design-qa-checklist, design-review-process, design-sprint-plan, handoff-spec, team-workflow, version-control-strategy.
---
# Design Ops

Streamline design operations with critique frameworks, handoff specs, sprint planning, review processes, and team workflows.

## How to use this skill

This bundles 9 focused skills. Find the one that matches the request in the table below, then read its file before answering — the table is only an index, the actual guidance lives in the linked files.

| Skill | File | Use it for |
| --- | --- | --- |
| `design-critique` | `skills/design-critique/SKILL.md` | Facilitate a structured team critique — framing, feedback rules, and actionable outcomes. |
| `design-debt-audit` | `skills/design-debt-audit/SKILL.md` | Inventory and prioritise accumulated design inconsistencies across a product. |
| `design-impact-reporting` | `skills/design-impact-reporting/SKILL.md` | Communicate design's contribution to business and user outcomes in stakeholder language. |
| `design-qa-checklist` | `skills/design-qa-checklist/SKILL.md` | Build a QA checklist for verifying that a build matches the design. |
| `design-review-process` | `skills/design-review-process/SKILL.md` | Establish review gates — criteria, checkpoints, and approval flow. |
| `design-sprint-plan` | `skills/design-sprint-plan/SKILL.md` | Plan and facilitate a design sprint from challenge framing through prototype testing. |
| `handoff-spec` | `skills/handoff-spec/SKILL.md` | Write the implementation handoff — measurements, behaviours, assets, states, and edge cases. |
| `team-workflow` | `skills/team-workflow/SKILL.md` | Design the team's operating rhythm — task management, collaboration rituals, and tooling. |
| `version-control-strategy` | `skills/version-control-strategy/SKILL.md` | Define version control for design files, components, and libraries — branching, naming, and release. |

## Multi-step workflows

These chain several of the skills above into one end-to-end process. Read the file when a request matches the whole workflow rather than a single skill.

- `commands/handoff.md` — Run the full handoff workflow — specs, measurements, assets, states, and a QA checklist — and output a developer-ready package.
- `commands/plan-sprint.md` — Run a design sprint end to end — challenge framing, schedule, exercises, and prototype test plan.
- `commands/setup-workflow.md` — Set up a team's operating rhythm end to end — rituals, task flow, tooling, review gates, and version control.

## Attribution

From the Designer Skills suite by MC Dean (https://github.com/Owl-Listener/designer-skills), MIT licensed.
