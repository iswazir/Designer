---
name: design-systems
description: Build, document, and maintain scalable design systems — from tokens and components to accessibility and theming. Covers: accessibility-audit, component-spec, design-system-governance, design-token, documentation-template, icon-system, localization-design, motion-system, naming-convention, pattern-library, theming-system.
---
# Design Systems

Build, document, and maintain scalable design systems — from tokens and components to accessibility and theming.

## How to use this skill

This bundles 11 focused skills as reference files. Match the request to a row below, then read that file before answering — the table is only an index, the guidance itself lives in the files.

| Skill | File | Use it for |
| --- | --- | --- |
| `accessibility-audit` | `reference/accessibility-audit.md` | Audit an existing interface against WCAG, producing findings with severity ratings and remediation steps |
| `component-spec` | `reference/component-spec.md` | Specify one component — props, states, variants, accessibility, and usage rules |
| `design-system-governance` | `reference/design-system-governance.md` | Define how the system evolves — contribution model, versioning, deprecation, and change management |
| `design-token` | `reference/design-token.md` | Define and organise tokens for colour, spacing, type, and elevation with naming and usage rules |
| `documentation-template` | `reference/documentation-template.md` | Generate a reusable documentation scaffold for components, patterns, or guidelines |
| `icon-system` | `reference/icon-system.md` | Specify an icon system — grid, sizing, stroke weight, naming, categories, and implementation |
| `localization-design` | `reference/localization-design.md` | Design for multiple languages, writing directions, and cultural contexts — text expansion, RTL mirroring, and… |
| `motion-system` | `reference/motion-system.md` | Define motion tokens — durations, easing vocabulary, and reduced-motion handling — for consistency… |
| `naming-convention` | `reference/naming-convention.md` | Establish naming rules for components, tokens, and layers with patterns and worked examples |
| `pattern-library` | `reference/pattern-library.md` | Structure a pattern entry — problem context, solution, usage examples, and related patterns |
| `theming-system` | `reference/theming-system.md` | Design theming architecture — brand variants, dark mode, and high-contrast — mapped through token layers |

## Multi-step workflows

Each chains several skills above into one end-to-end process. Read the file when the request matches the whole workflow, not a single skill.

- `workflows/audit-system.md` — Run a comprehensive audit of an existing design system for consistency, completeness, and accessibility
- `workflows/create-component.md` — Scaffold a full component specification end to end — props, states, variants, accessibility, and documentation
- `workflows/tokenize.md` — Extract tokens from an existing design or stylesheet and organise them — naming, structure, and theme mapping

## Attribution

From the Designer Skills suite by MC Dean (https://github.com/Owl-Listener/designer-skills), MIT licensed.
