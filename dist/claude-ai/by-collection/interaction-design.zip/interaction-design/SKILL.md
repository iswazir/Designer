---
name: interaction-design
description: Design meaningful interactions with micro-animations, state machines, gestures, error handling, and feedback patterns. Covers: animation-principles, conversational-ux, doherty-threshold, error-handling-ux, feedback-patterns, fitts-law, form-design, gesture-patterns, hicks-law, interfaces-that-feel, jakobs-law, loading-states, micro-interaction-spec, millers-law, navigation-patterns, onboarding-design, peak-end-rule, search-ux, serial-position-effect, state-machine, teslers-law, zeigarnik-effect.
---
# Interaction Design

Design meaningful interactions with micro-animations, state machines, gestures, error handling, and feedback patterns.

## How to use this skill

This bundles 22 focused skills as reference files. Match the request to a row below, then read that file before answering — the table is only an index, the guidance itself lives in the files.

| Skill | File | Use it for |
| --- | --- | --- |
| `animation-principles` | `reference/animation-principles.md` | Apply animation principles — easing, staging, follow-through — to one specific UI motion |
| `conversational-ux` | `reference/conversational-ux.md` | Design voice and conversational interfaces — dialog flows, error recovery, and persona |
| `doherty-threshold` | `reference/doherty-threshold.md` | Apply the Doherty Threshold — keep system response under 400ms to preserve user flow |
| `error-handling-ux` | `reference/error-handling-ux.md` | Design error prevention, detection, and recovery across a product — message content, placement, and escape… |
| `feedback-patterns` | `reference/feedback-patterns.md` | Design confirmations, status updates, and notifications that tell users an action registered |
| `fitts-law` | `reference/fitts-law.md` | Apply Fitts's Law — target acquisition time depends on size and distance |
| `form-design` | `reference/form-design.md` | Design a form end to end — field order, grouping, validation, and completion |
| `gesture-patterns` | `reference/gesture-patterns.md` | Design gesture interactions for touch and pointer — swipe, drag, long-press, and their discoverability |
| `hicks-law` | `reference/hicks-law.md` | Apply Hick's Law — decision time grows with the number of simultaneous choices |
| `interfaces-that-feel` | `reference/interfaces-that-feel.md` | Apply an emotional resonance lens to a UI that is technically correct but flat, prescribing changes at the… |
| `jakobs-law` | `reference/jakobs-law.md` | Apply Jakob's Law — users expect your product to work like the others they already use |
| `loading-states` | `reference/loading-states.md` | Design waiting experiences — spinners, skeletons, optimistic updates, and progressive reveal |
| `micro-interaction-spec` | `reference/micro-interaction-spec.md` | Specify one micro-interaction completely — trigger, rules, feedback, loops, and modes |
| `millers-law` | `reference/millers-law.md` | Apply Miller's Law — chunk information into groups of about four to fit working memory |
| `navigation-patterns` | `reference/navigation-patterns.md` | Select and design a navigation pattern — tabs, drawer, hierarchy, or hub — matched to product structure and… |
| `onboarding-design` | `reference/onboarding-design.md` | Design the first-run experience — activation path, progressive disclosure, and time to first value |
| `peak-end-rule` | `reference/peak-end-rule.md` | Apply the Peak-End Rule — a flow is remembered by its most intense moment and its last |
| `search-ux` | `reference/search-ux.md` | Design search — query input, zero results, refinement, and result presentation |
| `serial-position-effect` | `reference/serial-position-effect.md` | Apply the Serial Position Effect — first and last items in a sequence are recalled best |
| `state-machine` | `reference/state-machine.md` | Model component behaviour as explicit states, events, and transitions |
| `teslers-law` | `reference/teslers-law.md` | Apply Tesler's Law — every process has irreducible complexity that someone must absorb |
| `zeigarnik-effect` | `reference/zeigarnik-effect.md` | Apply the Zeigarnik Effect — incomplete tasks stay mentally active |

## Multi-step workflows

Each chains several skills above into one end-to-end process. Read the file when the request matches the whole workflow, not a single skill.

- `workflows/design-form.md` — Design a form end to end — structure, decision points, chunking, validation, errors, and completion
- `workflows/design-interaction.md` — Design a complete interaction flow for a feature or component
- `workflows/design-onboarding.md` — Design a first-run experience end to end — activation path, progressive disclosure, and time to first value
- `workflows/error-flow.md` — Design an error flow end to end — prevention, detection, messaging, and recovery paths
- `workflows/map-states.md` — Model a component's states and transitions end to end — states, events, guards, and edge cases

## Attribution

From the Designer Skills suite by MC Dean (https://github.com/Owl-Listener/designer-skills), MIT licensed.
