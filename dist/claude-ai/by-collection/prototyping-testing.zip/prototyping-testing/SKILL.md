---
name: prototyping-testing
description: Plan and execute design validation through prototyping strategies, usability testing, heuristic evaluation, and A/B experiments. Covers: a-b-test-design, accessibility-test-plan, click-test-plan, heuristic-evaluation, prototype-strategy, test-scenario, user-flow-diagram, wireframe-spec.
---
# Prototyping Testing

Plan and execute design validation through prototyping strategies, usability testing, heuristic evaluation, and A/B experiments.

## How to use this skill

This bundles 8 focused skills as reference files. Match the request to a row below, then read that file before answering — the table is only an index, the guidance itself lives in the files.

| Skill | File | Use it for |
| --- | --- | --- |
| `a-b-test-design` | `reference/a-b-test-design.md` | Design an A/B experiment — hypothesis, variants, primary metric, and sample size |
| `accessibility-test-plan` | `reference/accessibility-test-plan.md` | Plan accessibility testing — assistive technologies, participant criteria, WCAG coverage, and session protocol |
| `click-test-plan` | `reference/click-test-plan.md` | Design first-click and click tests for findability and navigation |
| `heuristic-evaluation` | `reference/heuristic-evaluation.md` | Run an expert review against Nielsen's heuristics and domain criteria, with severity ratings |
| `prototype-strategy` | `reference/prototype-strategy.md` | Choose prototype fidelity and method to match the design question and the decision at stake |
| `test-scenario` | `reference/test-scenario.md` | Write realistic usability task scenarios with success criteria and facilitation notes |
| `user-flow-diagram` | `reference/user-flow-diagram.md` | Diagram screen-level paths, decision points, and branch logic |
| `wireframe-spec` | `reference/wireframe-spec.md` | Specify wireframe layout — content priority, component placement, and annotation |

## Multi-step workflows

Each chains several skills above into one end-to-end process. Read the file when the request matches the whole workflow, not a single skill.

- `workflows/evaluate.md` — Run a heuristic evaluation end to end — expert review against heuristics with severity ratings and…
- `workflows/experiment.md` — Design an A/B experiment end to end — hypothesis, variants, primary metric, and sample size
- `workflows/prototype-plan.md` — Create a prototyping and testing plan for a design initiative
- `workflows/test-plan.md` — Choose a testing method and build the plan around it — method selection, task scenarios, click tests, and…

## Attribution

From the Designer Skills suite by MC Dean (https://github.com/Owl-Listener/designer-skills), MIT licensed.
