---
name: ui-design
description: Craft polished user interfaces with layout grids, color systems, typography scales, responsive patterns, and visual hierarchy. Covers: aesthetic-usability, color-system, dark-mode-design, data-visualization, illustration-style, law-of-closure, law-of-common-region, law-of-continuity, law-of-figure-ground, law-of-proximity, law-of-similarity, layout-grid, platform-conventions, readable-measure, responsive-design, spacing-system, typography-scale, visual-hierarchy, von-restorff-effect.
---
# UI Design

Craft polished user interfaces with layout grids, color systems, typography scales, responsive patterns, and visual hierarchy.

## How to use this skill

This bundles 19 focused skills as reference files. Match the request to a row below, then read that file before answering — the table is only an index, the guidance itself lives in the files.

| Skill | File | Use it for |
| --- | --- | --- |
| `aesthetic-usability` | `reference/aesthetic-usability.md` | Apply the Aesthetic-Usability Effect — polished, consistent interfaces are perceived as more usable and… |
| `color-system` | `reference/color-system.md` | Build a product colour system — tonal scales, semantic roles, and contrast compliance |
| `dark-mode-design` | `reference/dark-mode-design.md` | Adapt an existing palette to dark mode — surface elevation, contrast rebalancing, and desaturation rules |
| `data-visualization` | `reference/data-visualization.md` | Select chart types and design data encodings — marks, axes, labels, and accessible chart styling |
| `illustration-style` | `reference/illustration-style.md` | Define an illustration style guide — visual language, colour usage, and application rules |
| `law-of-closure` | `reference/law-of-closure.md` | Apply the Law of Closure — the eye completes implied shapes from partial forms |
| `law-of-common-region` | `reference/law-of-common-region.md` | Apply the Law of Common Region — a shared container, background, or border groups elements regardless of… |
| `law-of-continuity` | `reference/law-of-continuity.md` | Apply the Law of Continuity — the eye follows alignment and unbroken paths |
| `law-of-figure-ground` | `reference/law-of-figure-ground.md` | Apply the Law of Figure-Ground — establish which layer is foreground and actionable versus background |
| `law-of-proximity` | `reference/law-of-proximity.md` | Apply the Law of Proximity — spatial closeness groups elements more strongly than any other cue |
| `law-of-similarity` | `reference/law-of-similarity.md` | Apply the Law of Similarity — shared colour, shape, or size signals that elements belong to one category |
| `layout-grid` | `reference/layout-grid.md` | Define a responsive grid — columns, gutters, margins, and breakpoint behaviour |
| `platform-conventions` | `reference/platform-conventions.md` | Design to iOS and Android conventions — what each OS mandates, where they diverge, and when to unify |
| `readable-measure` | `reference/readable-measure.md` | Set line length and measure for comfortable reading across type sizes and breakpoints |
| `responsive-design` | `reference/responsive-design.md` | Design layouts and interactions that adapt across screen sizes and input methods |
| `spacing-system` | `reference/spacing-system.md` | Create a spacing scale from a base unit with rules for when each step applies |
| `typography-scale` | `reference/typography-scale.md` | Create a modular type scale with size, weight, and line-height relationships |
| `visual-hierarchy` | `reference/visual-hierarchy.md` | Establish hierarchy through size, weight, colour, spacing, and position so the eye lands in the intended order |
| `von-restorff-effect` | `reference/von-restorff-effect.md` | Apply the Von Restorff Effect — the element that differs from its neighbours is the one remembered |

## Multi-step workflows

Each chains several skills above into one end-to-end process. Read the file when the request matches the whole workflow, not a single skill.

- `workflows/color-palette.md` — Run the full colour workflow — tonal scales, semantic mapping, contrast checks, dark mode, and chart colours…
- `workflows/design-screen.md` — Design a complete screen layout from a description or requirements
- `workflows/platform-audit.md` — Audit a design for iOS and Android convention compliance — navigation, controls, typography, and…
- `workflows/responsive-audit.md` — Audit a design's responsive behaviour across breakpoints — layout, touch targets, and content reflow
- `workflows/type-system.md` — Build a typography system end to end — scale, weights, line heights, measure, and responsive behaviour

## Attribution

From the Designer Skills suite by MC Dean (https://github.com/Owl-Listener/designer-skills), MIT licensed.
