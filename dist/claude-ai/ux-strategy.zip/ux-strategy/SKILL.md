---
name: ux-strategy
description: Shape product direction through competitive analysis, design principles, experience mapping, and strategic alignment. Covers: business-design, competitive-analysis, content-strategy, design-brief, design-principles, experience-map, information-architecture, metrics-definition, north-star-vision, opportunity-framework, service-blueprint, stakeholder-alignment.
---
# UX Strategy

Shape product direction through competitive analysis, design principles, experience mapping, and strategic alignment.

## How to use this skill

This bundles 12 focused skills. Find the one that matches the request in the table below, then read its file before answering — the table is only an index, the actual guidance lives in the linked files.

| Skill | File | Use it for |
| --- | --- | --- |
| `business-design` | `skills/business-design/SKILL.md` | Read financials, map competitive landscapes, and argue design decisions in the language of value. |
| `competitive-analysis` | `skills/competitive-analysis/SKILL.md` | Compare UX patterns, features, strengths, and gaps across rival products. |
| `content-strategy` | `skills/content-strategy/SKILL.md` | Define what content a product needs, how it is structured, and who owns it. |
| `design-brief` | `skills/design-brief/SKILL.md` | Write a project brief — problem space, constraints, audience, and success criteria. |
| `design-principles` | `skills/design-principles/SKILL.md` | Define actionable principles that resolve trade-offs when the team disagrees. |
| `experience-map` | `skills/experience-map/SKILL.md` | Map the full ecosystem of touchpoints, channels, and relationships across a service. |
| `information-architecture` | `skills/information-architecture/SKILL.md` | Design content structure, hierarchy, labelling, and the navigation model. |
| `metrics-definition` | `skills/metrics-definition/SKILL.md` | Define UX metrics and KPIs that connect design decisions to measurable outcomes. |
| `north-star-vision` | `skills/north-star-vision/SKILL.md` | Articulate a long-horizon product vision that aligns teams and anchors strategy. |
| `opportunity-framework` | `skills/opportunity-framework/SKILL.md` | Identify, score, and prioritise design opportunities against impact and effort. |
| `service-blueprint` | `skills/service-blueprint/SKILL.md` | Map service delivery across frontstage actions, backstage processes, and supporting systems. |
| `stakeholder-alignment` | `skills/stakeholder-alignment/SKILL.md` | Build alignment artifacts — responsibility matrices, decision rights, and communication plans. |

## Multi-step workflows

These chain several of the skills above into one end-to-end process. Read the file when a request matches the whole workflow rather than a single skill.

- `commands/benchmark.md` — Run a competitive benchmark across a set of products — pattern comparison, gap analysis, and opportunity callouts.
- `commands/frame-problem.md` — Structure an ambiguous design challenge into a clear problem definition with constraints and criteria.
- `commands/strategize.md` — Develop a complete UX strategy for a product or feature area.

## Attribution

From the Designer Skills suite by MC Dean (https://github.com/Owl-Listener/designer-skills), MIT licensed.
