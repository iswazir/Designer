---
name: designer-skills
description: Complete design practice toolkit — user research, design systems, UX strategy, UI craft, interaction design, prototyping and testing, design ops, and visual critique. Use for any design task: personas, journey maps, usability tests, design tokens, component specs, information architecture, user flows, colour systems, typography scales, layout grids, responsive and dark mode, accessibility, micro-interactions, animation, error states, design critique, and design team process.
---
# Designer Skills

107 design skills across nine areas of practice, plus end-to-end workflows.

## How to use this skill

Match the request to a row in the tables below, then read that reference file before answering. The tables are only an index — the actual guidance lives in the files, so read the relevant one rather than working from the summary. Read more than one when a request spans areas (a screen design might pull `layout-grid`, `color-system`, and `visual-hierarchy` together).

If nothing matches closely, answer normally rather than forcing a poor fit.

## Design Research

| Skill | File | Use it for |
| --- | --- | --- |
| `affinity-diagram` | `reference/design-research/affinity-diagram.md` | Cluster many qualitative data points into themes and insight statements |
| `card-sort-analysis` | `reference/design-research/card-sort-analysis.md` | Analyse open or closed card sort results into a proposed grouping and… |
| `diary-study-plan` | `reference/design-research/diary-study-plan.md` | Design a diary study — prompts, cadence, duration, participant… |
| `empathy-map` | `reference/design-research/empathy-map.md` | Build a Says, Thinks, Does, Feels map for one user or segment |
| `interview-script` | `reference/design-research/interview-script.md` | Write a structured interview guide — warm-up, core exploration, and… |
| `jobs-to-be-done` | `reference/design-research/jobs-to-be-done.md` | Map functional, emotional, and social jobs with outcome expectations |
| `journey-map` | `reference/design-research/journey-map.md` | Map one persona's end-to-end experience with stages, touchpoints,… |
| `research-repository` | `reference/design-research/research-repository.md` | Build a repository that makes findings findable, reusable, and… |
| `summarize-interview` | `reference/design-research/summarize-interview.md` | Turn one interview transcript into themes, supporting quotes, and… |
| `survey-design` | `reference/design-research/survey-design.md` | Design unbiased survey instruments — question wording, scales, and… |
| `usability-test-plan` | `reference/design-research/usability-test-plan.md` | Design a usability study — research questions, methodology, participant… |
| `user-persona` | `reference/design-research/user-persona.md` | Build research-grounded personas with goals, frustrations, and… |

## Design Systems

| Skill | File | Use it for |
| --- | --- | --- |
| `accessibility-audit` | `reference/design-systems/accessibility-audit.md` | Audit an existing interface against WCAG, producing findings with… |
| `component-spec` | `reference/design-systems/component-spec.md` | Specify one component — props, states, variants, accessibility, and… |
| `design-system-governance` | `reference/design-systems/design-system-governance.md` | Define how the system evolves — contribution model, versioning,… |
| `design-token` | `reference/design-systems/design-token.md` | Define and organise tokens for colour, spacing, type, and elevation… |
| `documentation-template` | `reference/design-systems/documentation-template.md` | Generate a reusable documentation scaffold for components, patterns, or… |
| `icon-system` | `reference/design-systems/icon-system.md` | Specify an icon system — grid, sizing, stroke weight, naming,… |
| `localization-design` | `reference/design-systems/localization-design.md` | Design for multiple languages, writing directions, and cultural… |
| `motion-system` | `reference/design-systems/motion-system.md` | Define motion tokens — durations, easing vocabulary, and reduced-motion… |
| `naming-convention` | `reference/design-systems/naming-convention.md` | Establish naming rules for components, tokens, and layers with patterns… |
| `pattern-library` | `reference/design-systems/pattern-library.md` | Structure a pattern entry — problem context, solution, usage examples,… |
| `theming-system` | `reference/design-systems/theming-system.md` | Design theming architecture — brand variants, dark mode, and… |

## UX Strategy

| Skill | File | Use it for |
| --- | --- | --- |
| `business-design` | `reference/ux-strategy/business-design.md` | Read financials, map competitive landscapes, and argue design decisions… |
| `competitive-analysis` | `reference/ux-strategy/competitive-analysis.md` | Compare UX patterns, features, strengths, and gaps across rival products |
| `content-strategy` | `reference/ux-strategy/content-strategy.md` | Define what content a product needs, how it is structured, and who owns… |
| `design-brief` | `reference/ux-strategy/design-brief.md` | Write a project brief — problem space, constraints, audience, and… |
| `design-principles` | `reference/ux-strategy/design-principles.md` | Define actionable principles that resolve trade-offs when the team… |
| `experience-map` | `reference/ux-strategy/experience-map.md` | Map the full ecosystem of touchpoints, channels, and relationships… |
| `information-architecture` | `reference/ux-strategy/information-architecture.md` | Design content structure, hierarchy, labelling, and the navigation model |
| `metrics-definition` | `reference/ux-strategy/metrics-definition.md` | Define UX metrics and KPIs that connect design decisions to measurable… |
| `north-star-vision` | `reference/ux-strategy/north-star-vision.md` | Articulate a long-horizon product vision that aligns teams and anchors… |
| `opportunity-framework` | `reference/ux-strategy/opportunity-framework.md` | Identify, score, and prioritise design opportunities against impact and… |
| `service-blueprint` | `reference/ux-strategy/service-blueprint.md` | Map service delivery across frontstage actions, backstage processes,… |
| `stakeholder-alignment` | `reference/ux-strategy/stakeholder-alignment.md` | Build alignment artifacts — responsibility matrices, decision rights,… |

## UI Design

| Skill | File | Use it for |
| --- | --- | --- |
| `aesthetic-usability` | `reference/ui-design/aesthetic-usability.md` | Apply the Aesthetic-Usability Effect — polished, consistent interfaces… |
| `color-system` | `reference/ui-design/color-system.md` | Build a product colour system — tonal scales, semantic roles, and… |
| `dark-mode-design` | `reference/ui-design/dark-mode-design.md` | Adapt an existing palette to dark mode — surface elevation, contrast… |
| `data-visualization` | `reference/ui-design/data-visualization.md` | Select chart types and design data encodings — marks, axes, labels, and… |
| `illustration-style` | `reference/ui-design/illustration-style.md` | Define an illustration style guide — visual language, colour usage, and… |
| `law-of-closure` | `reference/ui-design/law-of-closure.md` | Apply the Law of Closure — the eye completes implied shapes from… |
| `law-of-common-region` | `reference/ui-design/law-of-common-region.md` | Apply the Law of Common Region — a shared container, background, or… |
| `law-of-continuity` | `reference/ui-design/law-of-continuity.md` | Apply the Law of Continuity — the eye follows alignment and unbroken… |
| `law-of-figure-ground` | `reference/ui-design/law-of-figure-ground.md` | Apply the Law of Figure-Ground — establish which layer is foreground… |
| `law-of-proximity` | `reference/ui-design/law-of-proximity.md` | Apply the Law of Proximity — spatial closeness groups elements more… |
| `law-of-similarity` | `reference/ui-design/law-of-similarity.md` | Apply the Law of Similarity — shared colour, shape, or size signals… |
| `layout-grid` | `reference/ui-design/layout-grid.md` | Define a responsive grid — columns, gutters, margins, and breakpoint… |
| `platform-conventions` | `reference/ui-design/platform-conventions.md` | Design to iOS and Android conventions — what each OS mandates, where… |
| `readable-measure` | `reference/ui-design/readable-measure.md` | Set line length and measure for comfortable reading across type sizes… |
| `responsive-design` | `reference/ui-design/responsive-design.md` | Design layouts and interactions that adapt across screen sizes and… |
| `spacing-system` | `reference/ui-design/spacing-system.md` | Create a spacing scale from a base unit with rules for when each step… |
| `typography-scale` | `reference/ui-design/typography-scale.md` | Create a modular type scale with size, weight, and line-height… |
| `visual-hierarchy` | `reference/ui-design/visual-hierarchy.md` | Establish hierarchy through size, weight, colour, spacing, and position… |
| `von-restorff-effect` | `reference/ui-design/von-restorff-effect.md` | Apply the Von Restorff Effect — the element that differs from its… |

## Interaction Design

| Skill | File | Use it for |
| --- | --- | --- |
| `animation-principles` | `reference/interaction-design/animation-principles.md` | Apply animation principles — easing, staging, follow-through — to one… |
| `conversational-ux` | `reference/interaction-design/conversational-ux.md` | Design voice and conversational interfaces — dialog flows, error… |
| `doherty-threshold` | `reference/interaction-design/doherty-threshold.md` | Apply the Doherty Threshold — keep system response under 400ms to… |
| `error-handling-ux` | `reference/interaction-design/error-handling-ux.md` | Design error prevention, detection, and recovery across a product —… |
| `feedback-patterns` | `reference/interaction-design/feedback-patterns.md` | Design confirmations, status updates, and notifications that tell users… |
| `fitts-law` | `reference/interaction-design/fitts-law.md` | Apply Fitts's Law — target acquisition time depends on size and distance |
| `form-design` | `reference/interaction-design/form-design.md` | Design a form end to end — field order, grouping, validation, and… |
| `gesture-patterns` | `reference/interaction-design/gesture-patterns.md` | Design gesture interactions for touch and pointer — swipe, drag,… |
| `hicks-law` | `reference/interaction-design/hicks-law.md` | Apply Hick's Law — decision time grows with the number of simultaneous… |
| `interfaces-that-feel` | `reference/interaction-design/interfaces-that-feel.md` | Apply an emotional resonance lens to a UI that is technically correct… |
| `jakobs-law` | `reference/interaction-design/jakobs-law.md` | Apply Jakob's Law — users expect your product to work like the others… |
| `loading-states` | `reference/interaction-design/loading-states.md` | Design waiting experiences — spinners, skeletons, optimistic updates,… |
| `micro-interaction-spec` | `reference/interaction-design/micro-interaction-spec.md` | Specify one micro-interaction completely — trigger, rules, feedback,… |
| `millers-law` | `reference/interaction-design/millers-law.md` | Apply Miller's Law — chunk information into groups of about four to fit… |
| `navigation-patterns` | `reference/interaction-design/navigation-patterns.md` | Select and design a navigation pattern — tabs, drawer, hierarchy, or… |
| `onboarding-design` | `reference/interaction-design/onboarding-design.md` | Design the first-run experience — activation path, progressive… |
| `peak-end-rule` | `reference/interaction-design/peak-end-rule.md` | Apply the Peak-End Rule — a flow is remembered by its most intense… |
| `search-ux` | `reference/interaction-design/search-ux.md` | Design search — query input, zero results, refinement, and result… |
| `serial-position-effect` | `reference/interaction-design/serial-position-effect.md` | Apply the Serial Position Effect — first and last items in a sequence… |
| `state-machine` | `reference/interaction-design/state-machine.md` | Model component behaviour as explicit states, events, and transitions |
| `teslers-law` | `reference/interaction-design/teslers-law.md` | Apply Tesler's Law — every process has irreducible complexity that… |
| `zeigarnik-effect` | `reference/interaction-design/zeigarnik-effect.md` | Apply the Zeigarnik Effect — incomplete tasks stay mentally active |

## Prototyping Testing

| Skill | File | Use it for |
| --- | --- | --- |
| `a-b-test-design` | `reference/prototyping-testing/a-b-test-design.md` | Design an A/B experiment — hypothesis, variants, primary metric, and… |
| `accessibility-test-plan` | `reference/prototyping-testing/accessibility-test-plan.md` | Plan accessibility testing — assistive technologies, participant… |
| `click-test-plan` | `reference/prototyping-testing/click-test-plan.md` | Design first-click and click tests for findability and navigation |
| `heuristic-evaluation` | `reference/prototyping-testing/heuristic-evaluation.md` | Run an expert review against Nielsen's heuristics and domain criteria,… |
| `prototype-strategy` | `reference/prototyping-testing/prototype-strategy.md` | Choose prototype fidelity and method to match the design question and… |
| `test-scenario` | `reference/prototyping-testing/test-scenario.md` | Write realistic usability task scenarios with success criteria and… |
| `user-flow-diagram` | `reference/prototyping-testing/user-flow-diagram.md` | Diagram screen-level paths, decision points, and branch logic |
| `wireframe-spec` | `reference/prototyping-testing/wireframe-spec.md` | Specify wireframe layout — content priority, component placement, and… |

## Design Ops

| Skill | File | Use it for |
| --- | --- | --- |
| `design-critique` | `reference/design-ops/design-critique.md` | Facilitate a structured team critique — framing, feedback rules, and… |
| `design-debt-audit` | `reference/design-ops/design-debt-audit.md` | Inventory and prioritise accumulated design inconsistencies across a… |
| `design-impact-reporting` | `reference/design-ops/design-impact-reporting.md` | Communicate design's contribution to business and user outcomes in… |
| `design-qa-checklist` | `reference/design-ops/design-qa-checklist.md` | Build a QA checklist for verifying that a build matches the design |
| `design-review-process` | `reference/design-ops/design-review-process.md` | Establish review gates — criteria, checkpoints, and approval flow |
| `design-sprint-plan` | `reference/design-ops/design-sprint-plan.md` | Plan and facilitate a design sprint from challenge framing through… |
| `handoff-spec` | `reference/design-ops/handoff-spec.md` | Write the implementation handoff — measurements, behaviours, assets,… |
| `team-workflow` | `reference/design-ops/team-workflow.md` | Design the team's operating rhythm — task management, collaboration… |
| `version-control-strategy` | `reference/design-ops/version-control-strategy.md` | Define version control for design files, components, and libraries —… |

## Designer Toolkit

| Skill | File | Use it for |
| --- | --- | --- |
| `case-study` | `reference/designer-toolkit/case-study.md` | Craft a portfolio case study with narrative arc, process evidence, and… |
| `design-negotiation` | `reference/designer-toolkit/design-negotiation.md` | Advocate for design quality, scope, and timeline with partners and… |
| `design-rationale` | `reference/designer-toolkit/design-rationale.md` | Write rationale connecting decisions to user needs, business goals, and… |
| `design-system-adoption` | `reference/designer-toolkit/design-system-adoption.md` | Create adoption strategy and enablement materials to drive design… |
| `design-token-audit` | `reference/designer-toolkit/design-token-audit.md` | Audit token usage across a product for coverage, drift, and hard-coded… |
| `presentation-deck` | `reference/designer-toolkit/presentation-deck.md` | Structure a design presentation for a specific audience and decision |
| `ux-writing` | `reference/designer-toolkit/ux-writing.md` | Write interface copy — microcopy, error messages, empty states, and CTAs |

## Visual Critique

| Skill | File | Use it for |
| --- | --- | --- |
| `critique-affordance` | `reference/visual-critique/critique-affordance.md` | Critique a rendered screen's affordances — what looks clickable, state… |
| `critique-brand-consistency` | `reference/visual-critique/critique-brand-consistency.md` | Critique a rendered screen against mood.md, voice.md, and tokens.md |
| `critique-color` | `reference/visual-critique/critique-color.md` | Critique a rendered screen's colour — contrast ratios, palette… |
| `critique-composition` | `reference/visual-critique/critique-composition.md` | Critique a rendered screen's composition — balance, whitespace, rhythm,… |
| `critique-information-density` | `reference/visual-critique/critique-information-density.md` | Critique a rendered screen's density — cognitive load, content… |
| `critique-typography` | `reference/visual-critique/critique-typography.md` | Critique a rendered screen's typography — scale usage, readability,… |
| `critique-visual-hierarchy` | `reference/visual-critique/critique-visual-hierarchy.md` | Critique a rendered screen's hierarchy — entry point, eye flow, weight… |

## Multi-step workflows

Each chains several skills into one end-to-end process. Read the file when the request matches a whole workflow rather than a single skill.

- **Design Research** — `workflows/design-research/discover.md`, `workflows/design-research/interview.md`, `workflows/design-research/synthesize.md`, `workflows/design-research/test-plan.md`
- **Design Systems** — `workflows/design-systems/audit-system.md`, `workflows/design-systems/create-component.md`, `workflows/design-systems/tokenize.md`
- **UX Strategy** — `workflows/ux-strategy/benchmark.md`, `workflows/ux-strategy/frame-problem.md`, `workflows/ux-strategy/strategize.md`
- **UI Design** — `workflows/ui-design/color-palette.md`, `workflows/ui-design/design-screen.md`, `workflows/ui-design/platform-audit.md`, `workflows/ui-design/responsive-audit.md`, `workflows/ui-design/type-system.md`
- **Interaction Design** — `workflows/interaction-design/design-form.md`, `workflows/interaction-design/design-interaction.md`, `workflows/interaction-design/design-onboarding.md`, `workflows/interaction-design/error-flow.md`, `workflows/interaction-design/map-states.md`
- **Prototyping Testing** — `workflows/prototyping-testing/evaluate.md`, `workflows/prototyping-testing/experiment.md`, `workflows/prototyping-testing/prototype-plan.md`, `workflows/prototyping-testing/test-plan.md`
- **Design Ops** — `workflows/design-ops/handoff.md`, `workflows/design-ops/plan-sprint.md`, `workflows/design-ops/setup-workflow.md`
- **Designer Toolkit** — `workflows/designer-toolkit/build-presentation.md`, `workflows/designer-toolkit/write-case-study.md`, `workflows/designer-toolkit/write-rationale.md`
- **Visual Critique** — `workflows/visual-critique/critique-screen.md`, `workflows/visual-critique/critique-ux.md`

## Attribution

From the Designer Skills suite by MC Dean (https://github.com/Owl-Listener/designer-skills), MIT licensed.
