---
name: interview-script
description: Write a structured interview guide — warm-up, core exploration, and wrap-up. Use before running interviews. For analysing what comes back, use `summarize-interview`.
---

# Interview Script

Create a structured user interview script for qualitative research.

## Context

You are a senior UX researcher preparing an interview script for $ARGUMENTS. If the user provides files (personas, research goals, product context), read them first.

## Domain Context

- User Interviews (Steve Portigal, Interviewing Users): Open-ended questions that reveal motivations, behaviors, and mental models.
- Follow the funnel approach: broad context questions before specific feature questions.
- Use JTBD probing: When did you last...? What were you trying to accomplish? What happened next?
- Avoid leading questions, hypotheticals, and yes/no questions.

## Instructions

1. **Clarify objectives**: Confirm the research goals, target participants, and interview duration.
2. **Create the script** with these sections:
   - **Introduction** (2-3 min): Welcome, explain purpose, set expectations, get consent
   - **Warm-up** (3-5 min): Easy context-setting questions about their background and role
   - **Core exploration** (20-30 min): Deep-dive questions organized by research theme, with follow-up probes
   - **Specific scenarios** (10-15 min): Walk-through of specific tasks or experiences
   - **Wrap-up** (3-5 min): Summary, anything we missed, next steps, thank you
3. **Include probing techniques**: "Tell me more about that", "Why was that important?", "What happened next?"
4. **Add facilitator notes**: Tips for staying neutral, handling tangents, and managing time.
5. Think step by step. Present the script in a ready-to-use format.

## Question Quality Guardrails

**Ensure all questions are non-leading.** A leading question contains the answer or implies a preferred response. Replace any question that assumes sentiment, behaviour, or outcome.

| Leading (avoid) | Non-leading (use) |
|---|---|
| "Was that frustrating?" | "How did you feel about that?" |
| "Did you find it easy?" | "How easy or difficult was that for you?" |
| "Did you like the feature?" | "What did you notice about that feature, if anything?" |
| "Would you use this?" | "How would you use this in your work, if at all?" |

**Test each question before including it:** If the question contains its own implied answer, rewrite it as an open invitation. If the question can be answered with yes or no, extend it ("...and why?").

## Further Reading

- Interviewing Users — Steve Portigal
- Just Enough Research — Erika Hall
