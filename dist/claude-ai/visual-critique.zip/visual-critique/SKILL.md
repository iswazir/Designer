---
name: visual-critique
description: Visual critique skills for designers: analyse hierarchy, brand consistency, composition, typography, colour, affordance, and information density — then compile a prioritised fix list. Covers: critique-affordance, critique-brand-consistency, critique-color, critique-composition, critique-information-density, critique-typography, critique-visual-hierarchy.
---
# Visual Critique

Visual critique skills for designers: analyse hierarchy, brand consistency, composition, typography, colour, affordance, and information density — then compile a prioritised fix list.

## How to use this skill

This bundles 7 focused skills. Find the one that matches the request in the table below, then read its file before answering — the table is only an index, the actual guidance lives in the linked files.

| Skill | File | Use it for |
| --- | --- | --- |
| `critique-affordance` | `skills/critique-affordance/SKILL.md` | Critique a rendered screen's affordances — what looks clickable, state visibility, CTA clarity, and action discoverability. |
| `critique-brand-consistency` | `skills/critique-brand-consistency/SKILL.md` | Critique a rendered screen against mood.md, voice.md, and tokens.md. |
| `critique-color` | `skills/critique-color/SKILL.md` | Critique a rendered screen's colour — contrast ratios, palette coherence, and semantic meaning. |
| `critique-composition` | `skills/critique-composition/SKILL.md` | Critique a rendered screen's composition — balance, whitespace, rhythm, and gestalt grouping. |
| `critique-information-density` | `skills/critique-information-density/SKILL.md` | Critique a rendered screen's density — cognitive load, content prioritisation, scanning patterns, and progressive disclosure. |
| `critique-typography` | `skills/critique-typography/SKILL.md` | Critique a rendered screen's typography — scale usage, readability, consistency, and token compliance. |
| `critique-visual-hierarchy` | `skills/critique-visual-hierarchy/SKILL.md` | Critique a rendered screen's hierarchy — entry point, eye flow, weight distribution, and emphasis. |

## Multi-step workflows

These chain several of the skills above into one end-to-end process. Read the file when a request matches the whole workflow rather than a single skill.

- `commands/critique-screen.md` — Run all seven visual critiques on a screen and output a prioritised fix list.
- `commands/critique-ux.md` — Run a focused UX critique on a screen — affordances, information density, and hierarchy — and output a prioritised fix list.

## Attribution

From the Designer Skills suite by MC Dean (https://github.com/Owl-Listener/designer-skills), MIT licensed.
