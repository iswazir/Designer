---
name: prototyping-testing
description: Plan and execute design validation through prototyping strategies, usability testing, heuristic evaluation, and A/B experiments. Covers: a-b-test-design, accessibility-test-plan, click-test-plan, heuristic-evaluation, prototype-strategy, test-scenario, user-flow-diagram, wireframe-spec.
---
# Prototyping Testing

Plan and execute design validation through prototyping strategies, usability testing, heuristic evaluation, and A/B experiments.

## How to use this skill

This bundles 8 focused skills. Find the one that matches the request in the table below, then read its file before answering — the table is only an index, the actual guidance lives in the linked files.

| Skill | File | Use it for |
| --- | --- | --- |
| `a-b-test-design` | `skills/a-b-test-design/SKILL.md` | Design an A/B experiment — hypothesis, variants, primary metric, and sample size. |
| `accessibility-test-plan` | `skills/accessibility-test-plan/SKILL.md` | Plan accessibility testing — assistive technologies, participant criteria, WCAG coverage, and session protocol. |
| `click-test-plan` | `skills/click-test-plan/SKILL.md` | Design first-click and click tests for findability and navigation. |
| `heuristic-evaluation` | `skills/heuristic-evaluation/SKILL.md` | Run an expert review against Nielsen's heuristics and domain criteria, with severity ratings. |
| `prototype-strategy` | `skills/prototype-strategy/SKILL.md` | Choose prototype fidelity and method to match the design question and the decision at stake. |
| `test-scenario` | `skills/test-scenario/SKILL.md` | Write realistic usability task scenarios with success criteria and facilitation notes. |
| `user-flow-diagram` | `skills/user-flow-diagram/SKILL.md` | Diagram screen-level paths, decision points, and branch logic. |
| `wireframe-spec` | `skills/wireframe-spec/SKILL.md` | Specify wireframe layout — content priority, component placement, and annotation. |

## Multi-step workflows

These chain several of the skills above into one end-to-end process. Read the file when a request matches the whole workflow rather than a single skill.

- `commands/evaluate.md` — Run a heuristic evaluation end to end — expert review against heuristics with severity ratings and recommended fixes.
- `commands/experiment.md` — Design an A/B experiment end to end — hypothesis, variants, primary metric, and sample size.
- `commands/prototype-plan.md` — Create a prototyping and testing plan for a design initiative.
- `commands/test-plan.md` — Choose a testing method and build the plan around it — method selection, task scenarios, click tests, and accessibility coverage.

## Attribution

From the Designer Skills suite by MC Dean (https://github.com/Owl-Listener/designer-skills), MIT licensed.
