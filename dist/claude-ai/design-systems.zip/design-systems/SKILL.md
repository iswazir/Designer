---
name: design-systems
description: Build, document, and maintain scalable design systems — from tokens and components to accessibility and theming. Covers: accessibility-audit, component-spec, design-system-governance, design-token, documentation-template, icon-system, localization-design, motion-system, naming-convention, pattern-library, theming-system.
---
# Design Systems

Build, document, and maintain scalable design systems — from tokens and components to accessibility and theming.

## How to use this skill

This bundles 11 focused skills. Find the one that matches the request in the table below, then read its file before answering — the table is only an index, the actual guidance lives in the linked files.

| Skill | File | Use it for |
| --- | --- | --- |
| `accessibility-audit` | `skills/accessibility-audit/SKILL.md` | Audit an existing interface against WCAG, producing findings with severity ratings and remediation steps. |
| `component-spec` | `skills/component-spec/SKILL.md` | Specify one component — props, states, variants, accessibility, and usage rules. |
| `design-system-governance` | `skills/design-system-governance/SKILL.md` | Define how the system evolves — contribution model, versioning, deprecation, and change management. |
| `design-token` | `skills/design-token/SKILL.md` | Define and organise tokens for colour, spacing, type, and elevation with naming and usage rules. |
| `documentation-template` | `skills/documentation-template/SKILL.md` | Generate a reusable documentation scaffold for components, patterns, or guidelines. |
| `icon-system` | `skills/icon-system/SKILL.md` | Specify an icon system — grid, sizing, stroke weight, naming, categories, and implementation. |
| `localization-design` | `skills/localization-design/SKILL.md` | Design for multiple languages, writing directions, and cultural contexts — text expansion, RTL mirroring, and locale formats. |
| `motion-system` | `skills/motion-system/SKILL.md` | Define motion tokens — durations, easing vocabulary, and reduced-motion handling — for consistency product-wide. |
| `naming-convention` | `skills/naming-convention/SKILL.md` | Establish naming rules for components, tokens, and layers with patterns and worked examples. |
| `pattern-library` | `skills/pattern-library/SKILL.md` | Structure a pattern entry — problem context, solution, usage examples, and related patterns. |
| `theming-system` | `skills/theming-system/SKILL.md` | Design theming architecture — brand variants, dark mode, and high-contrast — mapped through token layers. |

## Multi-step workflows

These chain several of the skills above into one end-to-end process. Read the file when a request matches the whole workflow rather than a single skill.

- `commands/audit-system.md` — Run a comprehensive audit of an existing design system for consistency, completeness, and accessibility.
- `commands/create-component.md` — Scaffold a full component specification end to end — props, states, variants, accessibility, and documentation.
- `commands/tokenize.md` — Extract tokens from an existing design or stylesheet and organise them — naming, structure, and theme mapping.

## Attribution

From the Designer Skills suite by MC Dean (https://github.com/Owl-Listener/designer-skills), MIT licensed.
