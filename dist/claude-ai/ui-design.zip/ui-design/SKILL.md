---
name: ui-design
description: Craft polished user interfaces with layout grids, color systems, typography scales, responsive patterns, and visual hierarchy. Covers: aesthetic-usability, color-system, dark-mode-design, data-visualization, illustration-style, law-of-closure, law-of-common-region, law-of-continuity, law-of-figure-ground, law-of-proximity, law-of-similarity, layout-grid, platform-conventions, readable-measure, responsive-design, spacing-system, typography-scale, visual-hierarchy, von-restorff-effect.
---
# UI Design

Craft polished user interfaces with layout grids, color systems, typography scales, responsive patterns, and visual hierarchy.

## How to use this skill

This bundles 19 focused skills. Find the one that matches the request in the table below, then read its file before answering — the table is only an index, the actual guidance lives in the linked files.

| Skill | File | Use it for |
| --- | --- | --- |
| `aesthetic-usability` | `skills/aesthetic-usability/SKILL.md` | Apply the Aesthetic-Usability Effect — polished, consistent interfaces are perceived as more usable and forgive minor friction. |
| `color-system` | `skills/color-system/SKILL.md` | Build a product colour system — tonal scales, semantic roles, and contrast compliance. |
| `dark-mode-design` | `skills/dark-mode-design/SKILL.md` | Adapt an existing palette to dark mode — surface elevation, contrast rebalancing, and desaturation rules. |
| `data-visualization` | `skills/data-visualization/SKILL.md` | Select chart types and design data encodings — marks, axes, labels, and accessible chart styling. |
| `illustration-style` | `skills/illustration-style/SKILL.md` | Define an illustration style guide — visual language, colour usage, and application rules. |
| `law-of-closure` | `skills/law-of-closure/SKILL.md` | Apply the Law of Closure — the eye completes implied shapes from partial forms. |
| `law-of-common-region` | `skills/law-of-common-region/SKILL.md` | Apply the Law of Common Region — a shared container, background, or border groups elements regardless of spacing. |
| `law-of-continuity` | `skills/law-of-continuity/SKILL.md` | Apply the Law of Continuity — the eye follows alignment and unbroken paths. |
| `law-of-figure-ground` | `skills/law-of-figure-ground/SKILL.md` | Apply the Law of Figure-Ground — establish which layer is foreground and actionable versus background. |
| `law-of-proximity` | `skills/law-of-proximity/SKILL.md` | Apply the Law of Proximity — spatial closeness groups elements more strongly than any other cue. |
| `law-of-similarity` | `skills/law-of-similarity/SKILL.md` | Apply the Law of Similarity — shared colour, shape, or size signals that elements belong to one category. |
| `layout-grid` | `skills/layout-grid/SKILL.md` | Define a responsive grid — columns, gutters, margins, and breakpoint behaviour. |
| `platform-conventions` | `skills/platform-conventions/SKILL.md` | Design to iOS and Android conventions — what each OS mandates, where they diverge, and when to unify. |
| `readable-measure` | `skills/readable-measure/SKILL.md` | Set line length and measure for comfortable reading across type sizes and breakpoints. |
| `responsive-design` | `skills/responsive-design/SKILL.md` | Design layouts and interactions that adapt across screen sizes and input methods. |
| `spacing-system` | `skills/spacing-system/SKILL.md` | Create a spacing scale from a base unit with rules for when each step applies. |
| `typography-scale` | `skills/typography-scale/SKILL.md` | Create a modular type scale with size, weight, and line-height relationships. |
| `visual-hierarchy` | `skills/visual-hierarchy/SKILL.md` | Establish hierarchy through size, weight, colour, spacing, and position so the eye lands in the intended order. |
| `von-restorff-effect` | `skills/von-restorff-effect/SKILL.md` | Apply the Von Restorff Effect — the element that differs from its neighbours is the one remembered. |

## Multi-step workflows

These chain several of the skills above into one end-to-end process. Read the file when a request matches the whole workflow rather than a single skill.

- `commands/color-palette.md` — Run the full colour workflow — tonal scales, semantic mapping, contrast checks, dark mode, and chart colours — and output a documented palette.
- `commands/design-screen.md` — Design a complete screen layout from a description or requirements.
- `commands/platform-audit.md` — Audit a design for iOS and Android convention compliance — navigation, controls, typography, and platform-specific gaps.
- `commands/responsive-audit.md` — Audit a design's responsive behaviour across breakpoints — layout, touch targets, and content reflow.
- `commands/type-system.md` — Build a typography system end to end — scale, weights, line heights, measure, and responsive behaviour.

## Attribution

From the Designer Skills suite by MC Dean (https://github.com/Owl-Listener/designer-skills), MIT licensed.
