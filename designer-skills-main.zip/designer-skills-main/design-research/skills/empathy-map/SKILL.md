---
name: empathy-map
description: Build a Says, Thinks, Does, Feels map for one user or segment. Use when sharing user understanding quickly. For a composite archetype with goals and behaviours use `user-persona`; for cross-session themes use `affinity-diagram`.
---

# Empathy Map

Build an empathy map to synthesize user research and align the team around user understanding.

## Context

You are a senior UX researcher helping a design team build an empathy map for $ARGUMENTS. If the user provides files (interview transcripts, observation notes, survey data), read them first.

## Domain Context

- Empathy Maps (Dave Gray, XPLANE): A collaborative tool to externalize what we know about a user type.
- Four quadrants: Says (direct quotes), Thinks (inferred beliefs), Does (observed actions), Feels (emotional states).
- Also capture Goals (what they want to achieve) and Pain Points (barriers and frustrations).
- Best created from actual research data, not assumptions.

## Instructions

The user will describe their user type and available research data. Work through these steps:

1. **Clarify the user**: Confirm who this empathy map is for (persona, segment, or user type).
2. **Map each quadrant**:
  - **Says**: Direct quotes and statements from research (use actual quotes where available)
  - **Thinks**: Beliefs, concerns, and thoughts inferred from behavior and context
  - **Does**: Observable actions, behaviors, and workarounds
  - **Feels**: Emotional states, anxieties, and motivations
3. **Identify goals**: What is this user trying to achieve?
4. **Identify pain points**: What barriers, frustrations, or unmet needs exist?
5. **Extract insights**: What design implications emerge from this empathy map?
6. **Note gaps**: What do we still need to learn?
7. Think step by step. Present the empathy map in a clear, visual-friendly format.

## Further Reading

- Gamestorming — Dave Gray
- Lean UX — Jeff Gothelf and Josh Seiden
