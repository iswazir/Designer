---
name: perceptual-protocols
description: >-
  Capture and communicate how a design should FEEL — mood, aesthetic vocabulary, motion character, brand voice, and sound — as structured markdown briefs an agent can read. Use when a design brief is vague about feel, when words like warm, restrained, playful, or premium need anchoring to something specific, when translating a moodboard or audio reference into a written brief, when recording the intent behind design tokens, when reverse-engineering the mood of an existing UI, or when critiquing generated design work against an agreed brief.
---
# Perceptual Protocols

Nine protocols for stating how something should feel, precisely enough that an agent can act on it. Each produces one plain markdown file that lives in the project and gets read alongside the code.

## How to use this skill

Pick the protocol matching the request from the table below and read its `PROMPT.md` — that file contains the actual protocol, including what to ask the user for. Read its `FORMAT.md` (or `SPEC.md`) before writing output, since the value of these files is that they follow a fixed shape other agents can parse. Read an `example-*.md` when the shape of a good result is unclear.

Produce the named output file as the deliverable. Do not invent a format — follow the spec.

| Protocol | Output | Reach for it when |
| --- | --- | --- |
| [`mood`](protocols/mood/PROMPT.md) | `mood.md` | the user has a moodboard, screenshots, or visual references and needs to state the intended feel |
| [`vocab`](protocols/vocab/PROMPT.md) | `vocab.md` | words like warm, restrained, or dense are being used loosely and need anchoring to references |
| [`motion`](protocols/motion/PROMPT.md) | `motion.md` | animation, transitions, easing, or the feel of movement is being specified |
| [`voice`](protocols/voice/PROMPT.md) | `voice.md` | tone of voice, copy personality, or writing style needs to be pinned down |
| [`listen`](protocols/listen/PROMPT.md) | `listen.md + sound.md` | music, soundtrack, sound design, or a recorded place is part of the brief |
| [`situation`](protocols/situation/PROMPT.md) | `situation.md` | the same product must feel different in different contexts (calm vs. urgent, first use vs. daily) |
| [`tokens`](protocols/tokens/PROMPT.md) | `tokens.md` | a token set or design system exists and needs the reasoning behind its values recorded |
| [`trace`](protocols/trace/PROMPT.md) | `trace.md` | an existing product or screenshot needs its unstated aesthetic reverse-engineered |
| [`critique`](protocols/critique/PROMPT.md) | `critique.md` | generated design work needs judging against a mood, vocab, or voice brief |

## How they compose

They work alone but are designed to stack, in this order:

1. **Declare intent** — `mood` from visual references, `listen` from audio.
2. **Share vocabulary** — `vocab` for static qualities, `motion` for movement, `voice` for writing.
3. **Weight by context** — `situation`, when the feel must shift by circumstance.
4. **Annotate the system** — `tokens`, once a design system exists.
5. **Read existing work** — `trace`, to recover the mood a live UI already has.
6. **Close the loop** — `critique`, to judge output against the brief.

When several of these files already exist in a project, read all of them before generating design work — they are written to be read together.

## Attribution

From Perceptual Protocols by Owl-Listener (https://github.com/Owl-Listener/perceptual-protocols), MIT licensed. The PNG moodboards and Python helpers in the source repo are omitted here; clone the repo for those.
