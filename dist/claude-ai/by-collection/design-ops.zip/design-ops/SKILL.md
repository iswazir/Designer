---
name: design-ops
description: Streamline design operations with critique frameworks, handoff specs, sprint planning, review processes, and team workflows. Covers: design-critique, design-debt-audit, design-impact-reporting, design-qa-checklist, design-review-process, design-sprint-plan, handoff-spec, team-workflow, version-control-strategy.
---
# Design Ops

Streamline design operations with critique frameworks, handoff specs, sprint planning, review processes, and team workflows.

## How to use this skill

This bundles 9 focused skills as reference files. Match the request to a row below, then read that file before answering — the table is only an index, the guidance itself lives in the files.

| Skill | File | Use it for |
| --- | --- | --- |
| `design-critique` | `reference/design-critique.md` | Facilitate a structured team critique — framing, feedback rules, and actionable outcomes |
| `design-debt-audit` | `reference/design-debt-audit.md` | Inventory and prioritise accumulated design inconsistencies across a product |
| `design-impact-reporting` | `reference/design-impact-reporting.md` | Communicate design's contribution to business and user outcomes in stakeholder language |
| `design-qa-checklist` | `reference/design-qa-checklist.md` | Build a QA checklist for verifying that a build matches the design |
| `design-review-process` | `reference/design-review-process.md` | Establish review gates — criteria, checkpoints, and approval flow |
| `design-sprint-plan` | `reference/design-sprint-plan.md` | Plan and facilitate a design sprint from challenge framing through prototype testing |
| `handoff-spec` | `reference/handoff-spec.md` | Write the implementation handoff — measurements, behaviours, assets, states, and edge cases |
| `team-workflow` | `reference/team-workflow.md` | Design the team's operating rhythm — task management, collaboration rituals, and tooling |
| `version-control-strategy` | `reference/version-control-strategy.md` | Define version control for design files, components, and libraries — branching, naming, and release |

## Multi-step workflows

Each chains several skills above into one end-to-end process. Read the file when the request matches the whole workflow, not a single skill.

- `workflows/handoff.md` — Run the full handoff workflow — specs, measurements, assets, states, and a QA checklist — and output a…
- `workflows/plan-sprint.md` — Run a design sprint end to end — challenge framing, schedule, exercises, and prototype test plan
- `workflows/setup-workflow.md` — Set up a team's operating rhythm end to end — rituals, task flow, tooling, review gates, and version control

## Attribution

From the Designer Skills suite by MC Dean (https://github.com/Owl-Listener/designer-skills), MIT licensed.
