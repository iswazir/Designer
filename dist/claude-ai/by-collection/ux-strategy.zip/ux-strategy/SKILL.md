---
name: ux-strategy
description: Shape product direction through competitive analysis, design principles, experience mapping, and strategic alignment. Covers: business-design, competitive-analysis, content-strategy, design-brief, design-principles, experience-map, information-architecture, metrics-definition, north-star-vision, opportunity-framework, service-blueprint, stakeholder-alignment.
---
# UX Strategy

Shape product direction through competitive analysis, design principles, experience mapping, and strategic alignment.

## How to use this skill

This bundles 12 focused skills as reference files. Match the request to a row below, then read that file before answering — the table is only an index, the guidance itself lives in the files.

| Skill | File | Use it for |
| --- | --- | --- |
| `business-design` | `reference/business-design.md` | Read financials, map competitive landscapes, and argue design decisions in the language of value |
| `competitive-analysis` | `reference/competitive-analysis.md` | Compare UX patterns, features, strengths, and gaps across rival products |
| `content-strategy` | `reference/content-strategy.md` | Define what content a product needs, how it is structured, and who owns it |
| `design-brief` | `reference/design-brief.md` | Write a project brief — problem space, constraints, audience, and success criteria |
| `design-principles` | `reference/design-principles.md` | Define actionable principles that resolve trade-offs when the team disagrees |
| `experience-map` | `reference/experience-map.md` | Map the full ecosystem of touchpoints, channels, and relationships across a service |
| `information-architecture` | `reference/information-architecture.md` | Design content structure, hierarchy, labelling, and the navigation model |
| `metrics-definition` | `reference/metrics-definition.md` | Define UX metrics and KPIs that connect design decisions to measurable outcomes |
| `north-star-vision` | `reference/north-star-vision.md` | Articulate a long-horizon product vision that aligns teams and anchors strategy |
| `opportunity-framework` | `reference/opportunity-framework.md` | Identify, score, and prioritise design opportunities against impact and effort |
| `service-blueprint` | `reference/service-blueprint.md` | Map service delivery across frontstage actions, backstage processes, and supporting systems |
| `stakeholder-alignment` | `reference/stakeholder-alignment.md` | Build alignment artifacts — responsibility matrices, decision rights, and communication plans |

## Multi-step workflows

Each chains several skills above into one end-to-end process. Read the file when the request matches the whole workflow, not a single skill.

- `workflows/benchmark.md` — Run a competitive benchmark across a set of products — pattern comparison, gap analysis, and opportunity…
- `workflows/frame-problem.md` — Structure an ambiguous design challenge into a clear problem definition with constraints and criteria
- `workflows/strategize.md` — Develop a complete UX strategy for a product or feature area

## Attribution

From the Designer Skills suite by MC Dean (https://github.com/Owl-Listener/designer-skills), MIT licensed.
