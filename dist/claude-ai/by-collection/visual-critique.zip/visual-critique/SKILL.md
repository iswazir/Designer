---
name: visual-critique
description: Visual critique skills for designers: analyse hierarchy, brand consistency, composition, typography, colour, affordance, and information density — then compile a prioritised fix list. Covers: critique-affordance, critique-brand-consistency, critique-color, critique-composition, critique-information-density, critique-typography, critique-visual-hierarchy.
---
# Visual Critique

Visual critique skills for designers: analyse hierarchy, brand consistency, composition, typography, colour, affordance, and information density — then compile a prioritised fix list.

## How to use this skill

This bundles 7 focused skills as reference files. Match the request to a row below, then read that file before answering — the table is only an index, the guidance itself lives in the files.

| Skill | File | Use it for |
| --- | --- | --- |
| `critique-affordance` | `reference/critique-affordance.md` | Critique a rendered screen's affordances — what looks clickable, state visibility, CTA clarity, and action… |
| `critique-brand-consistency` | `reference/critique-brand-consistency.md` | Critique a rendered screen against mood.md, voice.md, and tokens.md |
| `critique-color` | `reference/critique-color.md` | Critique a rendered screen's colour — contrast ratios, palette coherence, and semantic meaning |
| `critique-composition` | `reference/critique-composition.md` | Critique a rendered screen's composition — balance, whitespace, rhythm, and gestalt grouping |
| `critique-information-density` | `reference/critique-information-density.md` | Critique a rendered screen's density — cognitive load, content prioritisation, scanning patterns, and… |
| `critique-typography` | `reference/critique-typography.md` | Critique a rendered screen's typography — scale usage, readability, consistency, and token compliance |
| `critique-visual-hierarchy` | `reference/critique-visual-hierarchy.md` | Critique a rendered screen's hierarchy — entry point, eye flow, weight distribution, and emphasis |

## Multi-step workflows

Each chains several skills above into one end-to-end process. Read the file when the request matches the whole workflow, not a single skill.

- `workflows/critique-screen.md` — Run all seven visual critiques on a screen and output a prioritised fix list
- `workflows/critique-ux.md` — Run a focused UX critique on a screen — affordances, information density, and hierarchy — and output a…

## Attribution

From the Designer Skills suite by MC Dean (https://github.com/Owl-Listener/designer-skills), MIT licensed.
