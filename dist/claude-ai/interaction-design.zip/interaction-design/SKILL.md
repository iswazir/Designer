---
name: interaction-design
description: Design meaningful interactions with micro-animations, state machines, gestures, error handling, and feedback patterns. Covers: animation-principles, conversational-ux, doherty-threshold, error-handling-ux, feedback-patterns, fitts-law, form-design, gesture-patterns, hicks-law, interfaces-that-feel, jakobs-law, loading-states, micro-interaction-spec, millers-law, navigation-patterns, onboarding-design, peak-end-rule, search-ux, serial-position-effect, state-machine, teslers-law, zeigarnik-effect.
---
# Interaction Design

Design meaningful interactions with micro-animations, state machines, gestures, error handling, and feedback patterns.

## How to use this skill

This bundles 22 focused skills. Find the one that matches the request in the table below, then read its file before answering — the table is only an index, the actual guidance lives in the linked files.

| Skill | File | Use it for |
| --- | --- | --- |
| `animation-principles` | `skills/animation-principles/SKILL.md` | Apply animation principles — easing, staging, follow-through — to one specific UI motion. |
| `conversational-ux` | `skills/conversational-ux/SKILL.md` | Design voice and conversational interfaces — dialog flows, error recovery, and persona. |
| `doherty-threshold` | `skills/doherty-threshold/SKILL.md` | Apply the Doherty Threshold — keep system response under 400ms to preserve user flow. |
| `error-handling-ux` | `skills/error-handling-ux/SKILL.md` | Design error prevention, detection, and recovery across a product — message content, placement, and escape routes. |
| `feedback-patterns` | `skills/feedback-patterns/SKILL.md` | Design confirmations, status updates, and notifications that tell users an action registered. |
| `fitts-law` | `skills/fitts-law/SKILL.md` | Apply Fitts's Law — target acquisition time depends on size and distance. |
| `form-design` | `skills/form-design/SKILL.md` | Design a form end to end — field order, grouping, validation, and completion. |
| `gesture-patterns` | `skills/gesture-patterns/SKILL.md` | Design gesture interactions for touch and pointer — swipe, drag, long-press, and their discoverability. |
| `hicks-law` | `skills/hicks-law/SKILL.md` | Apply Hick's Law — decision time grows with the number of simultaneous choices. |
| `interfaces-that-feel` | `skills/interfaces-that-feel/SKILL.md` | Apply an emotional resonance lens to a UI that is technically correct but flat, prescribing changes at the copy, motion, and interaction layer. |
| `jakobs-law` | `skills/jakobs-law/SKILL.md` | Apply Jakob's Law — users expect your product to work like the others they already use. |
| `loading-states` | `skills/loading-states/SKILL.md` | Design waiting experiences — spinners, skeletons, optimistic updates, and progressive reveal. |
| `micro-interaction-spec` | `skills/micro-interaction-spec/SKILL.md` | Specify one micro-interaction completely — trigger, rules, feedback, loops, and modes. |
| `millers-law` | `skills/millers-law/SKILL.md` | Apply Miller's Law — chunk information into groups of about four to fit working memory. |
| `navigation-patterns` | `skills/navigation-patterns/SKILL.md` | Select and design a navigation pattern — tabs, drawer, hierarchy, or hub — matched to product structure and user tasks. |
| `onboarding-design` | `skills/onboarding-design/SKILL.md` | Design the first-run experience — activation path, progressive disclosure, and time to first value. |
| `peak-end-rule` | `skills/peak-end-rule/SKILL.md` | Apply the Peak-End Rule — a flow is remembered by its most intense moment and its last. |
| `search-ux` | `skills/search-ux/SKILL.md` | Design search — query input, zero results, refinement, and result presentation. |
| `serial-position-effect` | `skills/serial-position-effect/SKILL.md` | Apply the Serial Position Effect — first and last items in a sequence are recalled best. |
| `state-machine` | `skills/state-machine/SKILL.md` | Model component behaviour as explicit states, events, and transitions. |
| `teslers-law` | `skills/teslers-law/SKILL.md` | Apply Tesler's Law — every process has irreducible complexity that someone must absorb. |
| `zeigarnik-effect` | `skills/zeigarnik-effect/SKILL.md` | Apply the Zeigarnik Effect — incomplete tasks stay mentally active. |

## Multi-step workflows

These chain several of the skills above into one end-to-end process. Read the file when a request matches the whole workflow rather than a single skill.

- `commands/design-form.md` — Design a form end to end — structure, decision points, chunking, validation, errors, and completion.
- `commands/design-interaction.md` — Design a complete interaction flow for a feature or component.
- `commands/design-onboarding.md` — Design a first-run experience end to end — activation path, progressive disclosure, and time to first value.
- `commands/error-flow.md` — Design an error flow end to end — prevention, detection, messaging, and recovery paths.
- `commands/map-states.md` — Model a component's states and transitions end to end — states, events, guards, and edge cases.

## Attribution

From the Designer Skills suite by MC Dean (https://github.com/Owl-Listener/designer-skills), MIT licensed.
