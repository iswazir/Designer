---
name: design-research
description: User research skills for designers: personas, empathy maps, journey maps, interview scripts, usability testing, and card sorting. Covers: affinity-diagram, card-sort-analysis, diary-study-plan, empathy-map, interview-script, jobs-to-be-done, journey-map, research-repository, summarize-interview, survey-design, usability-test-plan, user-persona.
---
# Design Research

User research skills for designers: personas, empathy maps, journey maps, interview scripts, usability testing, and card sorting.

## How to use this skill

This bundles 12 focused skills as reference files. Match the request to a row below, then read that file before answering — the table is only an index, the guidance itself lives in the files.

| Skill | File | Use it for |
| --- | --- | --- |
| `affinity-diagram` | `reference/affinity-diagram.md` | Cluster many qualitative data points into themes and insight statements |
| `card-sort-analysis` | `reference/card-sort-analysis.md` | Analyse open or closed card sort results into a proposed grouping and label set |
| `diary-study-plan` | `reference/diary-study-plan.md` | Design a diary study — prompts, cadence, duration, participant criteria, and analysis frame |
| `empathy-map` | `reference/empathy-map.md` | Build a Says, Thinks, Does, Feels map for one user or segment |
| `interview-script` | `reference/interview-script.md` | Write a structured interview guide — warm-up, core exploration, and wrap-up |
| `jobs-to-be-done` | `reference/jobs-to-be-done.md` | Map functional, emotional, and social jobs with outcome expectations |
| `journey-map` | `reference/journey-map.md` | Map one persona's end-to-end experience with stages, touchpoints, emotions, and pain points |
| `research-repository` | `reference/research-repository.md` | Build a repository that makes findings findable, reusable, and cumulative across teams |
| `summarize-interview` | `reference/summarize-interview.md` | Turn one interview transcript into themes, supporting quotes, and action items |
| `survey-design` | `reference/survey-design.md` | Design unbiased survey instruments — question wording, scales, and sampling — to measure attitudes at scale |
| `usability-test-plan` | `reference/usability-test-plan.md` | Design a usability study — research questions, methodology, participant criteria, metrics, and facilitation… |
| `user-persona` | `reference/user-persona.md` | Build research-grounded personas with goals, frustrations, and behavioural patterns |

## Multi-step workflows

Each chains several skills above into one end-to-end process. Read the file when the request matches the whole workflow, not a single skill.

- `workflows/discover.md` — Run a full user research cycle — persona creation, empathy mapping, and journey mapping for a product or…
- `workflows/interview.md` — Prepare an interview script or summarize an interview transcript into structured insights
- `workflows/synthesize.md` — Synthesize research data into affinity diagrams, themes, and actionable insights
- `workflows/test-plan.md` — Run the full usability study workflow — research questions, participant criteria, tasks, metrics, and…

## Attribution

From the Designer Skills suite by MC Dean (https://marieclairedean.substack.com/), MIT licensed.
